﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndianBookStore.Models
{
    public class Order:Book
    {
        public int OrderId { get; set; }
        public DateTime OrderedTime { get; set; }
        public int NoOfQuantity  { get; set; }
        public int Status { get; set; }
        public int BookId { get; set; }
        public Guid UserId { get; set; }
        public enum OrderStatus
        {
            New = 1,
            Dispatched = 2,
            Delivered = 3,
            Cancelled = 4
        }
    }
}