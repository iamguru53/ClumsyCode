﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IndianBookStore.Models;

namespace IndianBookStore.Contract
{
    public class SoldOutProduct : IProduct
    {
        public string BookName { get; set; }
        public int BookId { get; set; }
        public int CategoryId { get; set; }
        public string Author { get; set; }
        public string Publication { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public decimal Price { get; set; }

        public Book GetBookById(int id)
        {
            throw new NotImplementedException();
        }
    }
}
