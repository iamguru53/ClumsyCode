﻿using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndianBookStore.Contract
{
    public interface IProduct
    {
        string BookName { get; set; }
        int BookId { get; set; }
        int CategoryId { get; set; }
        string Author { get; set; }
        string Publication { get; set; }                
        bool IsActive { get; set; }
        bool IsDeleted { get; set; }
        decimal Price { get; set; }
        Book GetBookById(int id);

    }
}
