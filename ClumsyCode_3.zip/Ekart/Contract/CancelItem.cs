﻿using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SQLite;
using System.Linq;
using System.Web;
using static IndianBookStore.Models.Order;

namespace IndianBookStore.Contract
{
    public class CancelItem : ICancelItem
    {
        public void CancelOrder(int orderId)
        {
            Book book = new Book();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {
                SQLiteCommand command = connection.CreateCommand();
                command.Parameters.AddWithValue("@orderId", OrderStatus.Cancelled);
                command.Parameters.AddWithValue("@OrderId", orderId);
                try
                {
                    string queryString = "UPDATE [ORDER] SET STATUS = @Status WHERE ORDERID = @ORDERID; ";
                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    connection.Open();

                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                }
            }
        }
    }
}