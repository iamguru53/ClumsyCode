﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IndianBookStore.Contract
{
    public class OrderItem : IOrderItem
    {
        public void CancelOrder(int orderId)
        {
            throw new NotImplementedException();
        }
    }
}