﻿using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using static IndianBookStore.Models.Order;
using IndianBookStore.Contract;

namespace Ekart.Controllers
{
    public class OrdersController : Controller
    {
        // GET: Orders
        public ActionResult Index()
        {
            ViewData["Orders"] = GetOrders();
            var a = ViewData["Orders"];
            return View();
        }
        public Book GetBookById(int id)
        {
            Book book = new Book();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {

                SQLiteCommand command = connection.CreateCommand();
                command.Parameters.AddWithValue("@id", id);


                try
                {
                    connection.Open();
                    string queryString = "select  * from Book where bookid =@id; ";

                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    SQLiteDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book = new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        public List<Order> GetOrders()
        {
            List<Order> order = new List<Order>();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {

                SQLiteCommand command = connection.CreateCommand();
                //command.Parameters.AddWithValue("@id", id);

                try
                {
                    connection.Open();
                    string queryString = "select * from [Order]o INNER JOIN Book b on o.BookId = b.BookId; ";

                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    SQLiteDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        order.Add(new Order()
                        {
                            OrderId = Convert.ToInt32(reader["OrderId"]),
                            Status = Convert.ToInt32(reader["Status"]),
                            NoOfQuantity = Convert.ToInt32(reader["NoOfQuantity"]),
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        });
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return order;
        }
        public JsonResult CancelItem(int bookId)
        {
            Cancel(bookId);
            return Json(new { Message = "success", JsonRequestBehavior.AllowGet });
        }

        private void Cancel(int orderId)
        {
            CancelItem i = new CancelItem();
            i.CancelOrder(orderId);
        }

        //public void Insert(Order order)
        //{
        //    Book book = new Book();
        //    string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

        //    using (SQLiteConnection connection = new SQLiteConnection(cs))
        //    {

        //        SQLiteCommand command = connection.CreateCommand();
        //        command.Parameters.AddWithValue("@id", id);


        //        try
        //        {
        //            connection.Open();
        //            string queryString = "select  * from Book where bookid =@id; ";

        //            command.CommandText = queryString;
        //            command.CommandType = System.Data.CommandType.Text;
        //            SQLiteDataReader reader = command.ExecuteReader();

        //            while (reader.Read())
        //            {

        //                book = new Book()
        //                {
        //                    BookId = Convert.ToInt32(reader["BookId"]),
        //                    BookName = reader["BookName"].ToString(),
        //                    Author = reader["Author"].ToString(),
        //                    CategoryId = Convert.ToInt32(reader["CategoryId"]),
        //                    Publication = reader["Publication"].ToString(),
        //                    Price = Convert.ToInt32(reader["Price"])
        //                };
        //            }
        //            reader.Close();
        //        }
        //        catch (Exception ex)
        //        {
        //        }
        //    }
        //    return book;
        //}
    }
}