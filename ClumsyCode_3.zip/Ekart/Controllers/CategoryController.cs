﻿using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndianBookStore.Controllers
{
    public class CategoryController : Controller
    {
        // GET: Category
        public ActionResult Index(string id)
        {
            ViewData["CategoryList"] = GetCategory();
            ViewData["Book"] = GetBookByCategory(id);
            return View();
        }
        public List<Book> GetBookByCategory(string category)
        {
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;
            List<Book> book = new List<Book>();
            using (SQLiteConnection connection = new SQLiteConnection(cs))

            //using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                                
                SQLiteCommand command = connection.CreateCommand();
                command.Parameters.AddWithValue("@Category", category);
                string queryString = "Select * from  Book  INNER JOIN CATEGORY ON Category.CategoryId = Book.CategoryId WHERE CATEGORYName = @Category; ";

                command.CommandText = queryString;
                command.CommandType = System.Data.CommandType.Text;
                try
                {
                    connection.Open();

                    SQLiteDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book.Add(new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        });
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        private List<string> GetCategory()
        {
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;
 
            List<Book> book = new List<Book>();
            List<string> category = new List<string>();

            using (var con = new SQLiteConnection(cs))
            {
                con.Open();
                using (SQLiteCommand cmd = con.CreateCommand())
                {
                    string queryString = "select * from category; ";

                    cmd.CommandText = queryString;
                    cmd.CommandType = System.Data.CommandType.Text;

                    SQLiteDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        category.Add(
                                reader["CategoryName"].ToString()
                            );

                    }
                }

            } 
            return category;
        }        

    }
}