﻿using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndianBookStore.Controllers
{
    public class BookController : Controller
    {
        // GET: Book
        public ActionResult Index(int id)
        {
            ViewData["CategoryList"] = GetCategory();
            var bk = GetBookById(id);
            ViewData["BookDetails"] = bk;
            return View();
        }
        public Book GetBookById(int id)
        {
            Book book = new Book();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {

                try
                {
                    connection.Open();
                    string queryString = "select  * from Book where bookid =@id; ";

                    SQLiteCommand command = connection.CreateCommand();
                    command.Parameters.AddWithValue("@id", id);
                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    SQLiteDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book = new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }        
        private List<string> GetCategory()
        {
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            List<Book> book = new List<Book>();
            List<string> category = new List<string>();

            using (var con = new SQLiteConnection(cs))
            {
                con.Open();
                using (SQLiteCommand cmd = con.CreateCommand())
                {
                    string queryString = "select * from category; ";

                    cmd.CommandText = queryString;
                    cmd.CommandType = System.Data.CommandType.Text;

                    SQLiteDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        category.Add(
                                reader["CategoryName"].ToString()
                            );

                    }
                }

            }
            return category;
        }
        public JsonResult AddToCart(int id)
        {
            List<int> BookIds = new List<int>();

            List<int> bid = Session["Cart"] as List<int>;
            if(bid!=null)
                BookIds = bid;
            BookIds.Add(id);

            Session["Cart"] = BookIds;            
            return Json(new { Message = "success", JsonRequestBehavior.AllowGet });
        }
    }
}