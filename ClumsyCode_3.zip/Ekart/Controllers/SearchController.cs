﻿using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndianBookStore.Controllers
{
    public class SearchController : Controller
    {
        // GET: Search


        public ActionResult Index(string id)

        {           
            ViewData["Book"] = SearchBook(id);
            return View();
        }
        public List<Book> SearchBook(string text)
        {
            List<Book> book = new List<Book>();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            using (SQLiteConnection connection = new SQLiteConnection(cs))

            //using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                //SqlCommand command = new SqlCommand("Select b.* from  [dbo].[Book] b INNER JOIN CATEGORY c ON c.CategoryId = b.CategoryId WHERE CATEGORYName like @text or  BookName like @text or AUthor like @text or Publication like @text;", connection);
                //command.Parameters.AddWithValue("@text", "%"+text+ "%");
                SQLiteCommand command = connection.CreateCommand();
                string queryString = "select  * from Book where bookname like @text; ";

                command.CommandText = queryString;
                command.CommandType = System.Data.CommandType.Text;
                command.Parameters.AddWithValue("@text", "%" + text + "%");
                try
                { 
                    connection.Open();

                    SQLiteDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book.Add(new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        });
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
    }
}