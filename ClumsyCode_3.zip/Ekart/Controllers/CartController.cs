﻿using IndianBookStore.Contract;
using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using static IndianBookStore.Models.Order;

namespace IndianBookStore.Controllers
{
    public class CartController : Controller
    {
        // GET: Cart
        public ActionResult ViewCart()
        {
            List<int> bookId = Session["Cart"] as List<int>;
            List<IProduct> books = new List<IProduct>();
            if (bookId != null)
            {
                foreach (var item in bookId)
                {
                    books.Add(GetBookById(item));
                }
            }
            ViewData["Cart"] = books;
            return View();
        }
        public IProduct GetBookById(int bookId)
        {
            IProduct book = new AvailableProduct();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;            

            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {
                SQLiteCommand command = connection.CreateCommand();
                command.Parameters.AddWithValue("@bookId", bookId);

                try
                {
                    connection.Open();
                    string queryString = "Select  AvailableCount from stock where bookid = @bookId; ";

                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    int availableCount = Convert.ToInt32(command.ExecuteScalar());
                    command.Cancel();
                    connection.Close();
                    if (availableCount > 0)
                        book = GetAvailableBookById(bookId);
                    else
                        book = GetSoldOutBookById(bookId);
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        public IProduct GetAvailableBookById(int id)
        {
            IProduct book = new AvailableProduct();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;
            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {
                SQLiteCommand command = connection.CreateCommand();
                command.Parameters.AddWithValue("@id", id);

                try
                {
                    connection.Open();
                    command = connection.CreateCommand();
                    command.Parameters.AddWithValue("@id", id);
                    string queryString = "select  * from Book where bookid =@id; ";
                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    SQLiteDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book = new AvailableProduct()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        public IProduct GetSoldOutBookById(int id)
        {
            IProduct book = new AvailableProduct();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;
            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {
                SQLiteCommand command = connection.CreateCommand();
                command.Parameters.AddWithValue("@id", id);

                try
                {
                    connection.Open();
                    command = connection.CreateCommand();
                    command.Parameters.AddWithValue("@id", id);
                    string queryString = "select  * from Book where bookid =@id; ";
                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    SQLiteDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book = new SoldOutProduct()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            Price = Convert.ToInt32(reader["Price"])
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        public Book GetBookByBookId(int id)
        {
            Book book = new Book();
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand("select  * from  [dbo].[Book] WHERE BookId = @id", connection);
                command.Parameters.AddWithValue("@id", id);


                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book = new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            IsDeleted = (bool)reader["IsDelete"],
                            IsActive = (bool)reader["IsActive"],
                            Price = Convert.ToDecimal(reader["Price"])
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }

        public JsonResult RemoveFromCart(int id)
        {
            List<int> BookIds = new List<int>();

            List<int> bid = Session["Cart"] as List<int>;
            if (bid != null)
            {
                bid.Remove(id);
                BookIds = bid;                
                Session["Cart"] = BookIds;
            }

            
            return Json(new { Message = "success", JsonRequestBehavior.AllowGet });
        }
        public JsonResult BuyNow()
        {
            List<int> bookIds = Session["Cart"] as List<int>;
            List<IProduct> books = new List<IProduct>();
            if (bookIds != null)
            {
                foreach (var item in bookIds)
                {
                    books.Add(GetBookById(item));
                }
            }
            foreach (var item in books)
            {
                /*  * Instead of calling BuyProduct method in ParentClass , here calling local function. 
                    * This voilates the rule by allowing to buy SoldOut Product.*/
                BuyProduct(item.BookId);
            }
            Session["Cart"] = null;
            return Json(new { Message = "success", JsonRequestBehavior.AllowGet });
        }
        public void BuyProduct(int productId)
        {
            Book book = new Book();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {
                SQLiteCommand command = connection.CreateCommand();
                command.Parameters.AddWithValue("@Status", OrderStatus.New);                
                command.Parameters.AddWithValue("@BookId", productId);
                command.Parameters.AddWithValue("@NoOfQuantity", 1);
                try
                {
                    string queryString = "INSERT INTO [ORDER](BookId,Status,NoOfQuantity) values(@BookId,@Status,@NoOfQuantity); ";
                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;
                    connection.Open();

                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                }
            }            
        }
    }
}