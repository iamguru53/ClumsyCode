﻿using IndianBookStore.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IndianBookStore.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var c = GetCategory();
            var b = GetBooks();
            ViewData["Book"] = GetBooks();
            var dd = ViewData["Book"];
            ViewData["CategoryList"] = GetAllCategory();            

            return View();
        }
        public List<Book> GetBooks() {
            List<Book> book = new List<Book>();
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;

            //using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            using (SQLiteConnection connection = new SQLiteConnection(cs))
            {
                connection.Open();
                //SqlCommand command = new SqlCommand("select top 10 * from  Book", connection);
                SQLiteCommand command = connection.CreateCommand();
                try
                {
                   
                    string queryString = "select  * from Book LIMIT 10; ";

                    command.CommandText = queryString;
                    command.CommandType = System.Data.CommandType.Text;                    
                    SQLiteDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {

                        book.Add(new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),                            
                            Price = Convert.ToInt32(reader["Price"])
                        });
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        private List<string> GetCategory() {
            List<string> category = new List<string>();
            using (SqlConnection connection =
            new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                 SqlCommand command = new SqlCommand("select top 10 * from  [dbo].[Category]", connection);
 
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        category.Add(
                                reader["CategoryName"].ToString()
                            );
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return category;
        }
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        private List<string> GetAllCategory()
        {
            string cs = ConfigurationManager.ConnectionStrings["myLocalDBConnectionString"].ConnectionString;
            string a = "";
            List<Book> book = new List<Book>();
            List<string> category = new List<string>();

            using (var con = new SQLiteConnection(cs))
            {
                con.Open();
                using (SQLiteCommand cmd = con.CreateCommand())
                {
                    string queryString = "select * from category; ";                    

                    cmd.CommandText = queryString;
                    cmd.CommandType = System.Data.CommandType.Text;

                    SQLiteDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        category.Add(
                                reader["CategoryName"].ToString()
                            );

                    }
                } 

            }
            var b = category;
            return category;
        }
    }
}