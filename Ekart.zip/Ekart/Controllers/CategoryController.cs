﻿using Ekart.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ekart.Controllers
{
    public class CategoryController : Controller
    {
        // GET: Category
        public ActionResult Index(string id)
        {
            ViewData["CategoryList"] = GetCategory();
            ViewData["Book"] = GetBookByCategory(id);
            return View();
        }
        public List<Book> GetBookByCategory(string category)
        {
            List<Book> book = new List<Book>();
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand("Select * from  [dbo].[Book] b INNER JOIN CATEGORY c ON c.CategoryId = b.CategoryId WHERE CATEGORYName = @Category;", connection);
                command.Parameters.AddWithValue("@Category", category);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book.Add(new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            IsDeleted = (bool)reader["IsDelete"],
                            IsActive = (bool)reader["IsActive"],
                            Price = Convert.ToDecimal(reader["Price"])
                        });
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        private List<string> GetCategory()
        {
            List<string> category = new List<string>();
            using (SqlConnection connection =
            new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
 
                SqlCommand command = new SqlCommand("select * from  [dbo].[Category]", connection);
 
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        category.Add(
                                reader["CategoryName"].ToString()
                            );
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return category;
        }


    }
}