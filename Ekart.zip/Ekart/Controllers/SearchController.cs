﻿using Ekart.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ekart.Controllers
{
    public class SearchController : Controller
    {
        // GET: Search


        public ActionResult Index(string id)

        {
            string text2 = "ponni";
            var bk = SearchBook(id);            
            ViewData["Book"] = SearchBook(id);
            return View();
        }
        public List<Book> SearchBook(string text)
        {
            List<Book> book = new List<Book>();
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand("Select b.* from  [dbo].[Book] b INNER JOIN CATEGORY c ON c.CategoryId = b.CategoryId WHERE CATEGORYName like @text or  BookName like @text or AUthor like @text or Publication like @text;", connection);
                command.Parameters.AddWithValue("@text", "%"+text+ "%");

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book.Add(new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            IsDeleted = (bool)reader["IsDelete"],
                            IsActive = (bool)reader["IsActive"],
                            Price = Convert.ToDecimal(reader["Price"])
                        });
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
    }
}