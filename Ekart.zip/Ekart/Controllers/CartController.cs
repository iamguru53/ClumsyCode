﻿using Ekart.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ekart.Controllers
{
    public class CartController : Controller
    {
        // GET: Cart
        public ActionResult ViewCart()
        {
            List<int> bookId = Session["Cart"] as List<int>;
            List<Book> books = new List<Book>();
            foreach(var item in bookId)
            {
                books.Add(GetBookById(item));
            }
            ViewData["Cart"] = books;
            return View();
        }
        public Book GetBookById(int id)
        {
            Book book = new Book();
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand("select  * from  [dbo].[Book] WHERE BookId = @id", connection);
                command.Parameters.AddWithValue("@id", id);


                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book = new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            IsDeleted = (bool)reader["IsDelete"],
                            IsActive = (bool)reader["IsActive"],
                            Price = Convert.ToDecimal(reader["Price"])
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }

        public JsonResult RemoveFromCart(int id)
        {
            List<int> BookIds = new List<int>();

            List<int> bid = Session["Cart"] as List<int>;
            if (bid != null)
            {
                bid.Remove(id);
                BookIds = bid;                
                Session["Cart"] = BookIds;
            }

            
            return Json(new { Message = "success", JsonRequestBehavior.AllowGet });
        }
    }
}