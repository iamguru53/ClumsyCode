﻿using Ekart.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ekart.Controllers
{
    public class BookController : Controller
    {
        // GET: Book
        public ActionResult Index(int id)
        {
            ViewData["CategoryList"] = GetCategory();
            var bk = GetBookById(id);
            ViewData["BookDetails"] = bk;
            return View();
        }
        public Book GetBookById(int id)
        {
            Book book = new Book();
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                SqlCommand command = new SqlCommand("select top 10 * from  [dbo].[Book] WHERE BookId = @id", connection);
                command.Parameters.AddWithValue("@id", id);


                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        book = new Book()
                        {
                            BookId = Convert.ToInt32(reader["BookId"]),
                            BookName = reader["BookName"].ToString(),
                            Author = reader["Author"].ToString(),
                            CategoryId = Convert.ToInt32(reader["CategoryId"]),
                            Publication = reader["Publication"].ToString(),
                            IsDeleted = (bool)reader["IsDelete"],
                            IsActive = (bool)reader["IsActive"],
                            Price = Convert.ToDecimal(reader["Price"])
                        };
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return book;
        }
        private List<string> GetCategory()
        {
            List<string> category = new List<string>();
            using (SqlConnection connection =
            new SqlConnection("Data Source=DESKTOP-MRMHP5S;Initial Catalog=LIBRARY;Integrated Security=True"))
            {
                 SqlCommand command = new SqlCommand("select * from  [dbo].[Category]", connection);
 
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {

                        category.Add(
                                reader["CategoryName"].ToString()
                            );
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                }
            }
            return category;
        }
        public JsonResult AddToCart(int id)
        {
            List<int> BookIds = new List<int>();

            List<int> bid = Session["Cart"] as List<int>;
            if(bid!=null)
                BookIds = bid;
            BookIds.Add(id);

            Session["Cart"] = BookIds;            
            return Json(new { Message = "success", JsonRequestBehavior.AllowGet });
        }
    }
}